<?php

class Feedback extends QModule {

    protected $version = '1.2';

    public function addLanguage($lang) {
        $q = $this->engine->db->query("SELECT params FROM " . DB_PREF . "modules WHERE name='feedback'");
        $arr = $q->row;
        $arr = unserialize($arr['params']);
        $arr['title_' . $lang]                  = $arr['title_' . DEF_LANG];
        $arr['kw_' . $lang]                     = $arr['kw_' . DEF_LANG];
        $arr['descr_' . $lang]                  = $arr['descr_' . DEF_LANG];
        $arr['sent_' . $lang]                   = $arr['sent_' . DEF_LANG];
        $arr['message_fail_' . $lang]           = $arr['message_fail_' . DEF_LANG];
        $arr['empty_vars_' . $lang]             = $arr['empty_vars_' . DEF_LANG];
        $arr['info_' . $lang]                   = $arr['info_' . DEF_LANG];
        $arr['caption_' . $lang]                = $arr['caption_' . DEF_LANG];
        $arr['send_' . $lang]                   = $arr['send_' . DEF_LANG];
        $arr['email_placeholder_' . $lang]      = $arr['email_placeholder_' . DEF_LANG];
        $arr['name_placeholder_' . $lang]       = $arr['name_placeholder_' . DEF_LANG];
        $arr['phone_placeholder_' . $lang]      = $arr['phone_placeholder_' . DEF_LANG];
        $arr['message_placeholder_' . $lang]    = $arr['message_placeholder_' . DEF_LANG];
        $q = $this->engine->db->query("UPDATE " . DB_PREF . "modules SET `params`='" . $this->engine->db->escape(serialize($arr)) . "' WHERE name='feedback'");
        if ($q) return true; else return false;
    }

    public function index() {
        if (isset($_POST['feedback'])) {
            if (
                ((bool)$this->params['email_required'] && empty($_POST['email'])) ||
                ((bool)$this->params['name_required'] && empty($_POST['name'])) ||
                ((bool)$this->params['phone_required'] && empty($_POST['phone'])) ||
                ((bool)$this->params['message_required'] && empty($_POST['message']))
            ) {
                $_SESSION['msg'] = 'empty_vars';
            } else {
                $mb = '<table><tr><td>Message from:</td><td>' . $_POST['name'] . '</td></tr>';
                $mb .= '<tr><td>Email:</td><td>' . $_POST['email'] . '</td></tr>';
                $mb .= '<tr><td>Phone:</td><td>' . $_POST['phone'] . '</td></tr>';
                $mb .= '<tr><td>Message:</td><td>' . $_POST['message'] . '</td></tr></table>';
                if ($this->engine->sendMail(EMAIL, 'system@' . $this->engine->host, 'System mailer', 'Feedback', $mb)) {
                    $_SESSION['msg'] = 'sent';
                } else {
                    $_SESSION['msg'] = 'message_fail';
                }
            }
            $this->engine->url->redirect($this->engine->url->full);
        }

        $this->engine->ERROR_404 = FALSE;
        $this->engine->document->setTitle($this->params['title_' . $_SESSION['lang']]);
        $this->engine->document->setMKeywords($this->params['kw_' . $_SESSION['lang']]);
        $this->engine->document->setMDescription($this->params['descr_' . $_SESSION['lang']]);
        if (isset($_SESSION['msg'])) {
            if ($_SESSION['msg'] == 'sent') {
                $this->data['text_message'] = $this->params['sent_' . $_SESSION['lang']];
                $this->data['class_message'] = 'success';
            } elseif ($_SESSION['msg'] == 'message_fail') {
                $this->data['text_message'] = $this->params['message_fail_' . $_SESSION['lang']];
                $this->data['class_message'] = 'error';
            } elseif ($_SESSION['msg'] == 'empty_vars') {
                $this->data['text_message'] = $this->params['empty_vars_' . $_SESSION['lang']];
                $this->data['class_message'] = 'error';
            }
            unset($_SESSION['msg']);
        }
        $this->data['info']                 = $this->params['info_' . $_SESSION['lang']];
        $this->data['caption']              = $this->params['caption_' . $_SESSION['lang']];
        $this->data['send']                 = $this->params['send_' . $_SESSION['lang']];
        $this->data['email_placeholder']    = $this->params['email_placeholder_' . $_SESSION['lang']];
        $this->data['name_placeholder']     = $this->params['name_placeholder_' . $_SESSION['lang']];
        $this->data['phone_placeholder']    = $this->params['phone_placeholder_' . $_SESSION['lang']];
        $this->data['message_placeholder']  = $this->params['message_placeholder_' . $_SESSION['lang']];
        $this->template = TEMPLATE . 'feedback.tpl';
    }
}